package com.example.qandq

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ============================================================
// KONFIGURASI DOKUMEN — edit di sini bila perlu
// ============================================================
const val JUDUL = "Pengecekan Kualitas dan Kuantitas SPBU Samanhudi"
const val NAMA_TTD_1 = "Raden Johan"      // tanda tangan bulat
const val NAMA_TTD_2 = "Perliq Pontumika" // tanda tangan segitiga
val PRODUK = listOf("Pertalite", "Pertamax", "Pertamax Turbo", "Solar", "Dexlite")

private val MerahPertamina = Color(0xFFED1C24)
private val BiruPertamina = Color(0xFF0072BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(primary = BiruPertamina, secondary = MerahPertamina)
            ) { QQApp() }
        }
    }
}

private fun hariIni(): String =
    SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID")).format(Date())

private fun angka(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

private fun selisihText(order: String, aktual: String): String {
    val o = angka(order) ?: return "-"
    val a = angka(aktual) ?: return "-"
    val d = a - o
    return String.format(Locale.US, "%+.1f L", d)
}

@Composable
fun QQApp() {
    val ctx = LocalContext.current
    var tanggal by rememberSaveable { mutableStateOf(hariIni()) }
    var noPolisi by rememberSaveable { mutableStateOf("") }
    var produk by rememberSaveable { mutableStateOf(PRODUK[0]) }
    var qtyOrder by rememberSaveable { mutableStateOf("") }
    var qtyAktual by rememberSaveable { mutableStateOf("") }
    var density by rememberSaveable { mutableStateOf("") }
    var suhu by rememberSaveable { mutableStateOf("") }
    var kualitas by rememberSaveable { mutableStateOf("") }
    var catatan by rememberSaveable { mutableStateOf("") }
    var ttd1 by rememberSaveable { mutableStateOf(false) }
    var ttd2 by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // ---- Header: logo Pertamina Retail + judul ----
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painterResource(R.drawable.logo_pertamina_retail),
                contentDescription = "Pertamina Retail",
                modifier = Modifier.size(84.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.width(8.dp))
            Text(
                JUDUL,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = BiruPertamina
            )
        }
        HorizontalDivider(thickness = 2.dp, color = MerahPertamina)

        Teks("Tanggal", tanggal) { tanggal = it }
        Teks("Nomor Polisi / Mobil Tangki", noPolisi) { noPolisi = it }

        Text("Produk", fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PRODUK.forEach { p ->
                FilterChip(selected = produk == p, onClick = { produk = p }, label = { Text(p) })
            }
        }

        Text("Kuantitas", fontWeight = FontWeight.SemiBold, color = BiruPertamina)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Teks("Sesuai DO (L)", qtyOrder, Modifier.weight(1f), angka = true) { qtyOrder = it }
            Teks("Aktual (L)", qtyAktual, Modifier.weight(1f), angka = true) { qtyAktual = it }
        }
        Text("Selisih: ${selisihText(qtyOrder, qtyAktual)}", fontWeight = FontWeight.Medium)

        Text("Kualitas", fontWeight = FontWeight.SemiBold, color = BiruPertamina)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Teks("Density (kg/L)", density, Modifier.weight(1f), angka = true) { density = it }
            Teks("Suhu (°C)", suhu, Modifier.weight(1f), angka = true) { suhu = it }
        }
        Teks("Hasil visual (jernih, terang, bebas air)", kualitas) { kualitas = it }
        Teks("Catatan", catatan, singleLine = false) { catatan = it }

        // ---- Kolom tanda tangan ----
        Text("Tanda Tangan", fontWeight = FontWeight.SemiBold, color = BiruPertamina)
        Text("Ketuk kotak untuk membubuhkan / menghapus tanda tangan.", fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KolomTtd(NAMA_TTD_1, R.drawable.ttd_bulat, ttd1, Modifier.weight(1f)) { ttd1 = !ttd1 }
            KolomTtd(NAMA_TTD_2, R.drawable.ttd_segitiga, ttd2, Modifier.weight(1f)) { ttd2 = !ttd2 }
        }

        Button(
            onClick = {
                val data = listOf(
                    "Tanggal" to tanggal,
                    "Nomor Polisi / Mobil Tangki" to noPolisi,
                    "Produk" to produk,
                    "Kuantitas sesuai DO" to "$qtyOrder L",
                    "Kuantitas aktual" to "$qtyAktual L",
                    "Selisih" to selisihText(qtyOrder, qtyAktual),
                    "Density" to "$density kg/L",
                    "Suhu" to "$suhu °C",
                    "Hasil visual" to kualitas,
                    "Catatan" to catatan
                )
                val file = buatPdf(ctx, data, ttd1, ttd2)
                bagikanPdf(ctx, file)
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MerahPertamina)
        ) { Text("Buat & Bagikan PDF", fontWeight = FontWeight.Bold) }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Teks(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    angka: Boolean = false,
    singleLine: Boolean = true,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
            keyboardType = if (angka) androidx.compose.ui.text.input.KeyboardType.Decimal
            else androidx.compose.ui.text.input.KeyboardType.Text
        ),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
private fun KolomTtd(nama: String, res: Int, signed: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Card(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().height(130.dp),
            border = BorderStroke(1.dp, Color.Gray),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Box(Modifier.fillMaxSize().padding(8.dp), Alignment.Center) {
                if (signed) {
                    Image(
                        painterResource(res),
                        contentDescription = "Tanda tangan $nama",
                        modifier = Modifier.fillMaxSize().clip(MaterialTheme.shapes.small),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Text("Ketuk untuk tanda tangan", fontSize = 12.sp, textAlign = TextAlign.Center, color = Color.Gray)
                }
            }
        }
        HorizontalDivider(Modifier.padding(top = 6.dp), color = Color.Black)
        Text(nama, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

// ---------------- PDF ----------------
private fun muatBitmap(ctx: Context, res: Int): Bitmap =
    BitmapFactory.decodeResource(ctx.resources, res)

private fun gambarFit(c: Canvas, bmp: Bitmap, box: RectF) {
    val s = minOf(box.width() / bmp.width, box.height() / bmp.height)
    val w = bmp.width * s
    val h = bmp.height * s
    val l = box.left + (box.width() - w) / 2
    val t = box.top + (box.height() - h) / 2
    c.drawBitmap(bmp, null, RectF(l, t, l + w, t + h), Paint(Paint.FILTER_BITMAP_FLAG))
}

fun buatPdf(ctx: Context, data: List<Pair<String, String>>, ttd1: Boolean, ttd2: Boolean): File {
    val doc = PdfDocument()
    val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
    val c = page.canvas
    val margin = 40f

    // Logo
    gambarFit(c, muatBitmap(ctx, R.drawable.logo_pertamina_retail), RectF(margin, 30f, margin + 100f, 130f))

    // Judul
    val judulPaint = Paint().apply {
        color = AColor.rgb(0, 114, 188); textSize = 17f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); isAntiAlias = true
    }
    c.drawText("Pengecekan Kualitas dan Kuantitas", margin + 115f, 70f, judulPaint)
    c.drawText("SPBU Samanhudi", margin + 115f, 94f, judulPaint)
    c.drawLine(margin, 140f, 595f - margin, 140f, Paint().apply { color = AColor.rgb(237, 28, 36); strokeWidth = 3f })

    // Tabel data
    val label = Paint().apply { textSize = 12f; isAntiAlias = true; typeface = Typeface.DEFAULT_BOLD }
    val isi = Paint().apply { textSize = 12f; isAntiAlias = true }
    val garis = Paint().apply { color = AColor.LTGRAY; strokeWidth = 1f }
    var y = 172f
    for ((k, v) in data) {
        c.drawText(k, margin, y, label)
        c.drawText(": " + v.ifBlank { "-" }, margin + 190f, y, isi)
        c.drawLine(margin, y + 7f, 595f - margin, y + 7f, garis)
        y += 26f
    }

    // Tanda tangan
    y += 30f
    val colW = (595f - 2 * margin) / 2
    val boxTop = y + 10f
    val boxH = 110f
    val names = listOf(NAMA_TTD_1 to (ttd1 to R.drawable.ttd_bulat), NAMA_TTD_2 to (ttd2 to R.drawable.ttd_segitiga))
    val nama = Paint().apply { textSize = 13f; isAntiAlias = true; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    names.forEachIndexed { i, (n, p) ->
        val left = margin + i * colW
        val cx = left + colW / 2
        if (p.first) gambarFit(c, muatBitmap(ctx, p.second), RectF(left + 20f, boxTop, left + colW - 20f, boxTop + boxH))
        c.drawLine(left + 30f, boxTop + boxH + 6f, left + colW - 30f, boxTop + boxH + 6f, Paint().apply { color = AColor.BLACK; strokeWidth = 1f })
        c.drawText(n, cx, boxTop + boxH + 24f, nama)
    }

    doc.finishPage(page)
    val dir = File(ctx.cacheDir, "pdf").apply { mkdirs() }
    val file = File(dir, "QandQ_SPBU_Samanhudi_${System.currentTimeMillis()}.pdf")
    file.outputStream().use { doc.writeTo(it) }
    doc.close()
    return file
}

fun bagikanPdf(ctx: Context, file: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Bagikan PDF"))
}
